# Description

This is an item tracker for Metroid Fusion to use with [EmoTracker](https://emotracker.net). It can be hooked with Bizhawk to provide auto item tracking.

## Thanks

ChaosMiles07, Ridleymaster for the original SM icons (https://www.spriters-resource.com/custom_edited/metroidcustoms/sheet/23198/)